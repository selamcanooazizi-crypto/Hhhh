package dev.pvpvisuals;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class Config {
    public static boolean fpsHud = true, pingHud = true, cpsHud = true, armorHud = true,
            totemHud = true, killCounter = true, hitMarker = true, killSound = true,
            customCrosshair = true;
    public static int crosshairStyle = 0;   // 0 arti, 1 nokta, 2 kare
    public static int crosshairColor = 0;   // COLORS indeksi

    public static final int[] COLORS = {0xFFFFFFFF, 0xFFFF5555, 0xFF55FF55, 0xFF55FFFF, 0xFFFFFF55, 0xFFFF55FF};
    public static final String[] COLOR_NAMES = {"Beyaz", "Kirmizi", "Yesil", "Camgobegi", "Sari", "Pembe"};
    public static final String[] STYLE_NAMES = {"Arti", "Nokta", "Kare"};

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pvpvisuals.properties");

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (InputStream in = Files.newInputStream(FILE)) {
            Properties p = new Properties();
            p.load(in);
            fpsHud = b(p, "fpsHud", fpsHud);
            pingHud = b(p, "pingHud", pingHud);
            cpsHud = b(p, "cpsHud", cpsHud);
            armorHud = b(p, "armorHud", armorHud);
            totemHud = b(p, "totemHud", totemHud);
            killCounter = b(p, "killCounter", killCounter);
            hitMarker = b(p, "hitMarker", hitMarker);
            killSound = b(p, "killSound", killSound);
            customCrosshair = b(p, "customCrosshair", customCrosshair);
            crosshairStyle = Math.floorMod(Integer.parseInt(p.getProperty("crosshairStyle", "0")), STYLE_NAMES.length);
            crosshairColor = Math.floorMod(Integer.parseInt(p.getProperty("crosshairColor", "0")), COLORS.length);
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("fpsHud", String.valueOf(fpsHud));
        p.setProperty("pingHud", String.valueOf(pingHud));
        p.setProperty("cpsHud", String.valueOf(cpsHud));
        p.setProperty("armorHud", String.valueOf(armorHud));
        p.setProperty("totemHud", String.valueOf(totemHud));
        p.setProperty("killCounter", String.valueOf(killCounter));
        p.setProperty("hitMarker", String.valueOf(hitMarker));
        p.setProperty("killSound", String.valueOf(killSound));
        p.setProperty("customCrosshair", String.valueOf(customCrosshair));
        p.setProperty("crosshairStyle", String.valueOf(crosshairStyle));
        p.setProperty("crosshairColor", String.valueOf(crosshairColor));
        try (OutputStream out = Files.newOutputStream(FILE)) {
            p.store(out, "PvP Visuals");
        } catch (Exception ignored) {
        }
    }

    private static boolean b(Properties p, String k, boolean d) {
        return Boolean.parseBoolean(p.getProperty(k, String.valueOf(d)));
    }
}
