package dev.pvpvisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class Hud {
    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        int y = 4;
        if (Config.fpsHud) {
            ctx.drawText(tr, mc.getCurrentFps() + " FPS", 4, y, 0xFFFFFF, true);
            y += 11;
        }
        if (Config.pingHud) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            ctx.drawText(tr, ping + " ms", 4, y, 0xFFFFFF, true);
            y += 11;
        }
        if (Config.cpsHud) {
            ctx.drawText(tr, PvpVisualsClient.cps + " CPS", 4, y, 0xFFFFFF, true);
            y += 11;
        }
        if (Config.totemHud) {
            int totems = mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
            ctx.drawText(tr, "Totem: " + totems, 4, y, totems > 0 ? 0xFFD700 : 0xFF5555, true);
            y += 11;
        }
        if (Config.killCounter) {
            ctx.drawText(tr, "Kill: " + PvpVisualsClient.kills, 4, y, 0xFFFFFF, true);
        }

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        if (Config.armorHud) {
            int x = w - 22;
            int ay = h / 2 - 40;
            for (int i = 3; i >= 0; i--) {
                ItemStack s = mc.player.getInventory().armor.get(i);
                if (!s.isEmpty()) {
                    ctx.drawItem(s, x, ay);
                    ctx.drawItemInSlot(tr, s, x, ay);
                }
                ay += 20;
            }
        }

        int cx = w / 2;
        int cy = h / 2;
        int col = Config.COLORS[Config.crosshairColor];

        if (Config.customCrosshair) {
            switch (Config.crosshairStyle) {
                case 0 -> {
                    ctx.fill(cx - 5, cy, cx - 1, cy + 1, col);
                    ctx.fill(cx + 2, cy, cx + 6, cy + 1, col);
                    ctx.fill(cx, cy - 5, cx + 1, cy - 1, col);
                    ctx.fill(cx, cy + 2, cx + 1, cy + 6, col);
                }
                case 1 -> ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, col);
                default -> {
                    ctx.fill(cx - 4, cy - 4, cx + 4, cy - 3, col);
                    ctx.fill(cx - 4, cy + 3, cx + 4, cy + 4, col);
                    ctx.fill(cx - 4, cy - 3, cx - 3, cy + 3, col);
                    ctx.fill(cx + 3, cy - 3, cx + 4, cy + 3, col);
                }
            }
        }

        if (Config.hitMarker && PvpVisualsClient.hitTicks > 0) {
            int hc = 0xFFFF3333;
            for (int i = 4; i <= 8; i++) {
                ctx.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, hc);
                ctx.fill(cx - i, cy + i, cx - i + 1, cy + i + 1, hc);
                ctx.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, hc);
                ctx.fill(cx - i, cy - i, cx - i + 1, cy - i + 1, hc);
            }
        }
    }
}
