package dev.pvpvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class PvpVisualsClient implements ClientModInitializer {
    public static KeyBinding menuKey;

    public static int cps = 0;
    public static int kills = 0;
    public static int hitTicks = 0;

    private static final List<Long> clicks = new ArrayList<>();
    private static boolean wasDown = false;
    private static LivingEntity lastTarget = null;
    private static int lastAttackTick = 0;
    private static int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        Config.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pvpvisuals.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.pvpvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(PvpVisualsClient::tick);
        HudRenderCallback.EVENT.register(Hud::render);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) {
                hitTicks = 8;
                if (entity instanceof LivingEntity le) {
                    lastTarget = le;
                    lastAttackTick = tickCounter;
                }
            }
            return ActionResult.PASS;
        });
    }

    private static void tick(MinecraftClient mc) {
        tickCounter++;
        while (menuKey.wasPressed()) {
            mc.setScreen(new ConfigScreen());
        }
        if (hitTicks > 0) hitTicks--;
        if (mc.player == null) return;

        // CPS (sol tik)
        boolean down = mc.currentScreen == null
                && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (down && !wasDown) clicks.add(now);
        wasDown = down;
        clicks.removeIf(t -> now - t > 1000);
        cps = clicks.size();

        // Kill takibi
        if (lastTarget != null) {
            if (lastTarget.isDead() || lastTarget.getHealth() <= 0f) {
                kills++;
                if (Config.killSound) {
                    mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.2f, 1.0f));
                }
                lastTarget = null;
            } else if (tickCounter - lastAttackTick > 100) {
                lastTarget = null;
            }
        }
    }
}
