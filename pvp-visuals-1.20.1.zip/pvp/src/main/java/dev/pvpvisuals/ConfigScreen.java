package dev.pvpvisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class ConfigScreen extends Screen {
    private record Toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {}

    private final Toggle[] toggles = {
            new Toggle("FPS", () -> Config.fpsHud, v -> Config.fpsHud = v),
            new Toggle("Ping", () -> Config.pingHud, v -> Config.pingHud = v),
            new Toggle("CPS", () -> Config.cpsHud, v -> Config.cpsHud = v),
            new Toggle("Zirh HUD", () -> Config.armorHud, v -> Config.armorHud = v),
            new Toggle("Totem sayaci", () -> Config.totemHud, v -> Config.totemHud = v),
            new Toggle("Kill sayaci", () -> Config.killCounter, v -> Config.killCounter = v),
            new Toggle("Hit marker", () -> Config.hitMarker, v -> Config.hitMarker = v),
            new Toggle("Kill sesi", () -> Config.killSound, v -> Config.killSound = v),
            new Toggle("Ozel crosshair", () -> Config.customCrosshair, v -> Config.customCrosshair = v),
    };

    public ConfigScreen() {
        super(Text.literal("PvP Visuals"));
    }

    private static Text label(Toggle t) {
        return Text.literal(t.name() + ": " + (t.get().getAsBoolean() ? "ACIK" : "KAPALI"));
    }

    @Override
    protected void init() {
        int bw = 150, bh = 20, gap = 4;
        int left = width / 2 - bw - 2;
        int right = width / 2 + 2;
        int top = 30;

        for (int i = 0; i < toggles.length; i++) {
            Toggle t = toggles[i];
            int x = (i % 2 == 0) ? left : right;
            int y = top + (i / 2) * (bh + gap);
            addDrawableChild(ButtonWidget.builder(label(t), b -> {
                t.set().accept(!t.get().getAsBoolean());
                b.setMessage(label(t));
            }).dimensions(x, y, bw, bh).build());
        }

        int rows = (toggles.length + 1) / 2;
        int y2 = top + rows * (bh + gap) + 6;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Crosshair: " + Config.STYLE_NAMES[Config.crosshairStyle]), b -> {
                    Config.crosshairStyle = (Config.crosshairStyle + 1) % Config.STYLE_NAMES.length;
                    b.setMessage(Text.literal("Crosshair: " + Config.STYLE_NAMES[Config.crosshairStyle]));
                }).dimensions(left, y2, bw, bh).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Renk: " + Config.COLOR_NAMES[Config.crosshairColor]), b -> {
                    Config.crosshairColor = (Config.crosshairColor + 1) % Config.COLORS.length;
                    b.setMessage(Text.literal("Renk: " + Config.COLOR_NAMES[Config.crosshairColor]));
                }).dimensions(right, y2, bw, bh).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Bitti"), b -> close())
                .dimensions(width / 2 - 75, y2 + bh + gap + 6, 150, bh).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void removed() {
        Config.save();
    }
}
