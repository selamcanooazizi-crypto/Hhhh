PvP Visuals - Fabric 1.20.1
GitHub'a yukle -> Actions sekmesi -> Build -> Artifacts -> pvpvisuals-jar
Jar icinde -sources olmayan dosyayi mods klasorune at (Fabric API gerekli).
Menu: Sag Shift
